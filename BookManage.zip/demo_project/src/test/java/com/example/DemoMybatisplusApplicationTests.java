package com.example;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.dao.BookDao;
import com.example.domain.Book;
import com.example.service.BookService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class DemoMybatisplusApplicationTests {

    @Autowired
    private BookService bookService;

    @Autowired
    private BookDao bookDao;

    @Test
    void getAll() {
        List<Book> bookList = bookService.getAll();
    }

    @Test
    void testSave(){
        Book book = new Book();
        book.setBookName("23333");
        book.setDescription("15465");
        book.setType("历史轻小说");
        bookService.saveBook(book);
    }

    @Test
    void testDelete(){
        bookService.deleteById(14);
    }

    @Test
    void testUpdate(){
        Book book = new Book();
        book.setBookId(13);
        book.setBookName("2222222");
        book.setDescription("333333");
        book.setType("JIAGUWEN");
        bookService.Update(book);
    }

    @Test
    void getPages(){
        List pages = bookService.getPages(2,5);
    }

    @Test
    void selects(){
//        bookService.selectByType("市场");
//        bookService.selectByBookName("Spring");
        List<Book> books = bookService.selectByDep("888");
//        System.out.println(books);
    }






}
