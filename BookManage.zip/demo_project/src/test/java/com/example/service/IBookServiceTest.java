package com.example.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.domain.Book;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class IBookServiceTest {

    @Autowired
    private IBookService bookService;

    @Test
    void test1(){
        Book byId = bookService.getById(3);
    }

    @Test
    void testSave(){
        Book book = new Book();
        book.setBookName("258");
        book.setDescription("369");
        book.setType("历史轻小说");
        bookService.save(book);
    }

    @Test
    void testDelete(){
        bookService.removeById(22);
    }

    @Test
    void testUpdate(){
        Book book = new Book();
        book.setBookId(13);
        book.setBookName("2222222");
        book.setDescription("333333");
        book.setType("JIAGUWEN");
        bookService.updateById(book);
    }


    @Test
    void testPage(){
        IPage<Book> page = bookService.getPage(2, 3);
        System.out.println(page);

    }

}
